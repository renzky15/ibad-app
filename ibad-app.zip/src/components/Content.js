import React, { Component } from 'react'
import Mailbox from '../components/Mailbox';

export default class Content extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
