declare module '@latticehr/react-org-chart';
declare module 'react-orgchart';
declare module '@keymastervn/react-org-chart-next';
declare module 'react-input-validation';
declare module 'react-cardstack';